package com.capg.wallet.utils;

public class TransactionException extends Exception {

	/**
	 * Thrown when a transaction error occur
	 */
	private static final long serialVersionUID = 1L;

}
