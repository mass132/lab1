package lab14.com.cg.eis.service;

	public interface EmployeeServiceI {
		public void setUserInformation(int id,String name,int salary,String designation);
		public String getUserData();
	}

